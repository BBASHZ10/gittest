package ttlock.demo.iccard.model;

import java.util.ArrayList;

/**
 * Created on  2019/4/28 0028 17:07
 *
 * @author theodre
 */
public class ICCardListObj {
    ArrayList<ICCardObj> list;

    public ArrayList<ICCardObj> getList() {
        return list;
    }
}
