package ttlock.demo.lock.model;

/**
 * Created on  2019/4/28 0028 11:36
 *
 * @author theodore
 */
public class LockInitResultObj {
    int lockId;
    int keyId;

    public int getLockId() {
        return lockId;
    }

    public int getKeyId() {
        return keyId;
    }
}
