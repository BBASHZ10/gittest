package ttlock.demo.retrofit;

/**
 * Created by Administrator on 2018/1/17 0017.
 */

public interface onRequestResponse {
    void onResult(boolean success);
}
